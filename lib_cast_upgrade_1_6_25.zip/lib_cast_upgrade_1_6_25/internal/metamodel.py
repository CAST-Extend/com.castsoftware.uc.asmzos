import functools


class Attribute:
    """
    @deprecated: unused
    """
    def __init__(self):
        self.name = None
        self.value = None

    def get_value(self):
        return self.value

    def __repr__(self):
        return "Attribute(" + self.name + "," + str(self.value) + ")"


class Attributed:

    def __init__(self):
        self.id = None
        self.name = None
        self.description = None
        self.attributes = {}

    def get_name(self):
        return self.name

    def get_id(self):
        return self.id

    def get_description(self):
        return self.description

    def get_attributes(self):
        """
        A map attribute name -> str or int
        """
        return self.attributes


class Property(Attributed):

    def __init__(self):
        Attributed.__init__(self)
        # type of the property
        self.type = None
        # name of the type of the property
        self.type_name = None
        self.minimal_cardinality = 0
        self.maximal_cardinality = 1
        # category containing the property
        self.category = None

    def get_type(self):
        return self.type

    def get_minimal_cardinality(self):
        return self.minimal_cardinality

    def get_maximal_cardinality(self):
        return self.maximal_cardinality

    def __repr__(self):
        return "Property(" + self.name + "," + str(self.id) + ")"


class Category(Attributed):

    def __init__(self):
        Attributed.__init__(self)
        self.metamodel = None
        self.properties = set()
        self.inherited_categories = set()
        # useless
        self.sub_categories = set()
        # all types that inherit (transitivelly) from this category
        self.sub_types = set()
        self.all_inherited_categories = set()
        self.inherited_names = set()
        
        # for xml only
        self.xml_fragments = []
        
    def get_properties(self):
        return self.properties

    def get_direct_parents(self):
        return self.inherited_categories

    def is_language(self):
        """
        True when the category is a quality rule language.
        """
        return self.metamodel.get_category(name='CsvLanguage') in self.get_direct_parents()

    def inherit_from(self, category):
        """
        True if self inherit from category.

        @param category: can be a Category object or a name or an id
        """

        _type = type(category)

        if _type is str:
            category = self.metamodel.get_category(name=category)
        elif _type is int:
            category = self.metamodel.get_category(id=category)

        if self == category:
            return True
        
        if self.all_inherited_categories:

            return category in self.all_inherited_categories

        if category in self.inherited_categories:
            return True

        for parent in self.inherited_categories:
            if parent.inherit_from(category):
                return True

        return False

    def inherit_from_one_of(self, categories):
        """
        True if category inherit from one of categories.
        """

        if not categories:
            return True

        for category in categories:
            if self.inherit_from(category):
                return True

        return False

    def get_sub_types(self):
        """
        Return all sub types
        """
        return self.sub_types

    def is_type(self):
        return False

    def __repr__(self):

        if self.is_type():
            result = "Type("
        else:
            result = "Category("

        result = result + self.name + "," + str(self.id)

        for _property in self.properties:
            result = result + " " + str(_property)

        for category in self.inherited_categories:
            result = result + " " + str(category)

        return result + ')'


class Type(Category):

    def is_type(self):
        return True
    
    @functools.lru_cache(maxsize=None)
    def get_language(self):
        """
        Returns the quality rule language or None.
        """
        for cat in self.all_inherited_categories:
            if cat.is_language():
                return cat
    

class MetaModel:

    def __init__(self):
        # all categories and types
        self.categories = set()
        # all types
        self.types = set()
        self.properties = set()

        # all categories and types indexed by name
        self.categories_by_name = {}
        self.categories_by_id = {}
        self.properties_by_name = {}
        self.properties_by_id = {}

        self.delta = 0

    def get_categories(self):
        return self.categories

    def get_properties(self):
        return self.properties

    def get_types(self):
        return self.types

    def get_category(self, name=None, id=None):

        if name:
            return self.categories_by_name[name]

        if id:
            return self.categories_by_id[id]

        return None

    def get_property(self, name=None, id=None):
        if name:
            return self.properties_by_name[name]

        if id:
            return self.properties_by_id[id]

        return None
        
    def _add_category(self, category):

        self.categories.add(category)
        if category.get_id():
            self.categories_by_id[category.get_id()] = category
        if category.get_name():
            self.categories_by_name[category.get_name()] = category
        category.metamodel = self

    def _add_type(self, _type):

        self._add_category(_type)
        self.types.add(_type)
        _type.sub_types.add(_type)

    def _add_property(self, _property):

        if _property.get_id() in self.properties_by_id:
            raise RuntimeError("property already present")

        self.properties.add(_property)
        if _property.get_id():
            self.properties_by_id[_property.get_id()] = _property
        if _property.get_name():
            self.properties_by_name[_property.get_name()] = _property

    def _finalize(self, allow_partial=False):

        for _property in self.properties:

            if _property.type:
                continue
            category = self.get_category(name=_property.type_name)
            _property.type = category

        for category in self.categories:

            for name in category.inherited_names:
                try:
                    parent = self.get_category(name=name)
                    category.inherited_categories.add(parent)
                    parent.sub_categories.add(category)
                    if category.is_type():
                        parent.sub_types.add(category)
                except KeyError:
                    if not allow_partial:
                        raise

        # recursive inheritance
        def saturate_category(category):
            
            category.all_inherited_categories |= category.inherited_categories
            for parent in category.inherited_categories:
                saturate_category(parent)
                category.all_inherited_categories |= parent.all_inherited_categories

        # all_inherited_categories
        for category in self.categories:
            saturate_category(category)

        # sub_types and sub_categories
        for category in self.categories:
            if category.is_type():
                for parent in category.all_inherited_categories:
                    parent.sub_types.add(category)
            for parent in category.all_inherited_categories:
                parent.sub_categories.add(category)
                
         
class Filter:
    """
    Filter on types.
    """
    def __init__(self, metamodel):
        
        self.metamodel = metamodel
        self.positive_categories = []
        self.positive_categories_by_name_end = []
        self.positive_categories_by_name_begin_end = []
        self.negative_categories = []
    
    def add_category(self, name):
        """
        Add a category to the filter, meaning all types inheriting from that category
        """
        self.positive_categories.append(name)
    
    def add_category_by_name_end(self, name_end):
        """
        Add a category to the filter, meaning all types inheriting from that category
        """
        self.positive_categories_by_name_end.append(name_end)
    
    def add_category_by_name_begin_end(self, name_begin, name_end):
        """
        Add a category to the filter, meaning all types inheriting from that category
        """
        self.positive_categories_by_name_begin_end.append((name_begin, name_end))
    
    def remove_category(self, name):
        """
        Remove a category from teh filter, meaning all types inheriting from that category
        """
        self.negative_categories.append(name)
    
    def get_result(self):
        """
        Will calculate the final result once calls to add_category, remove_category are done
        returns a set of Category
        """
        result = set()
        def add_if_exist(name, result):
            try:
                category = self.metamodel.get_category(name=name)
                if category:
                    result.add(category)
            except KeyError:
                pass
        
        for name in self.positive_categories:
            add_if_exist(name, result)
            
        for name in self.positive_categories_by_name_end:
            result.update(self._get_by_name_end(name))
        
        for name_begin, name_end in self.positive_categories_by_name_begin_end:
            result.update(self._get_by_name_begin_end(name_begin, name_end))
        
        result = self._expand_types(result)
        
        # remove all types inheriting from one of negative_categories
        for name in self.negative_categories:
            try:
                category = self.metamodel.get_category(name=name)
                if category:
                    for t in category.get_sub_types():
                        result.remove(t)
            except KeyError:
                # category can be missing, so skip
                pass
        
        return result
    
    def _expand_types(self, categories):
        """
        given some categories, returns the equivalent in term of types
        """
        result = set()
        for category in categories:
            result.update(category.get_sub_types())
        
        return result
        
    def _get_by_name_end(self, name):
        result = set()
        for t in self.metamodel.categories:
            if t.name.endswith(name):
                result.add(t)
    
        return result
         
    def _get_by_name_begin_end(self, name_begin, name_end):
        result = set()
        for t in self.metamodel.categories:
            if t.name.startswith(name_begin) and t.name.endswith(name_end):
                result.add(t)
    
        return result

                    
class MetaModelConcepts:
    """
    Because upgrade is played after loading, the metamodel is already loaded and constructed.
    So we cannot really add methods to MetaModel class.
    
    This wrapper handle this situation.
    """
    def __init__(self, metamodel):
        self.metamodel = metamodel
        
    @functools.lru_cache(maxsize=None)
    def get_web_service_operation(self):

        f = Filter(self.metamodel)
        f.add_category('operation')
        f.remove_category('WBS_OPERATION')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_web_service_call(self):
        """
        Gives the list of categories representing web services calls.
        
        CAST_ResourceService
        CAST_WebServiceLinker_Resource
        CAST_SOAP_OperationCall
        """

        f = Filter(self.metamodel)
        f.add_category('CAST_ResourceService')
        f.add_category('CAST_WebServiceLinker_Resource')
        f.add_category('CAST_SOAP_OperationCall')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_rest_web_service_call(self):
        """
        Gives the list of categories representing REST calls.

        CAST_ResourceService
        CAST_WebServiceLinker_Resource
        """
        f = Filter(self.metamodel)
        f.add_category('CAST_ResourceService')
        f.add_category('CAST_WebServiceLinker_Resource')
        f.remove_category('CAST_DotNet_SOAP_Proxy')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_rest_web_service_receive(self):
        """
        Gives the list of categories representing REST receives.

        CAST_WebService_Operation
        CAST_WebServiceLinker_Operation
        """
        f = Filter(self.metamodel)
        f.add_category('CAST_WebService_Operation')
        f.add_category('CAST_WebServiceLinker_Operation')
        f.remove_category('CAST_DotNet_SOAP_Server')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_soap_web_service_call(self):
        """
        Gives the list of categories representing SOAP calls.

        CAST_SOAP_OperationCall
        """
        f = Filter(self.metamodel)
        f.add_category('CAST_SOAP_OperationCall')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_soap_web_service_receive(self):
        """
        Gives the list of categories representing SOAP receive.

        CAST_SOAP_Operation
        """
        f = Filter(self.metamodel)
        f.add_category('CAST_SOAP_Operation')
        f.remove_category('WBS_OPERATION') # inheritance added was incorrect
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_nosql_collection(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_Java_NoSQL_Collection')
        f.add_category('CAST_DotNet_NoSQL_Collection')
        f.add_category('CAST_NodeJS_NoSQL_Collection')
        f.add_category('CAST_AWS_Bucket')
        f.add_category('CAST_AWS_DynamodbTable')
        f.add_category('CAST_SHELL_AWS_DynamoDB_Table')
        f.add_category('CAST_SHELL_AWS_Unknown_DynamoDB_Table')
        f.add_category('CAST_Azure_Blob_Container')

        f.add_category('CAST_GCP_Bigtable_Table')
        f.add_category('CAST_CosmosDB_Collection')
        f.add_category('CAST_NodeJS_CosmosDB_Unknown_Collection')
        f.add_category('CAST_SHELL_AWS_Unknown_S3_Bucket')
        f.add_category('CAST_Cassandra_Table')
        
        f.add_category_by_name_end('_Collection')
        f.add_category_by_name_end('_S3_Bucket')
        f.add_category_by_name_end('_DynamoDB_Table')
        f.add_category_by_name_end('_Couchbase_Bucket')
        
        # for older versions
        f.add_category_by_name_begin_end('CAST_Java_', '_Collection')
        f.add_category_by_name_begin_end('CAST_DotNet_', '_Collection')

        # bugs
        f.remove_category('CAST_DotNet_GCP_PubSub_Publisher')
        f.remove_category('CAST_DotNet_GCP_PubSub_Receiver')
        f.remove_category('CAST_DotNet_GCP_PubSub_Subscription')
        f.remove_category('CAST_Java_GCP_PubSub_Publisher')
        f.remove_category('CAST_Java_GCP_PubSub_Receiver')
        f.remove_category('CAST_Java_GCP_PubSub_Subscription')
        f.remove_category('CAST_Web_Asp_Collection')
        
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_program_call(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_CallToProgram')
        f.add_category('CAST_CallToJavaProgram')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_bean(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_Web_AllBeans')
        f.add_category('CAST_Spring_AllBeans')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_cloud_function(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_AWS_Lambda')
        f.add_category('CAST_Azure_Function')
        f.remove_category('CAST_NodeJS_AWS_Lambda_Function_ANY')
        f.remove_category('CAST_NodeJS_AWS_Lambda_Function_DELETE')
        f.remove_category('CAST_NodeJS_AWS_Lambda_Function_GET')
        f.remove_category('CAST_NodeJS_AWS_Lambda_Function_POST')
        f.remove_category('CAST_NodeJS_AWS_Lambda_Function_PUT')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_cloud_function_call(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_CallTo_AWS_Lambda')
        f.add_category('CAST_CallTo_Azure_Function')
        f.add_category_by_name_end('_Lambda_Call')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_rpc_receive(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_gRPC_Method')
        f.add_category('CAST_GenericRPC_Method')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_rpc_call(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_CallTo_gRPC_Method')
        f.add_category('CAST_GenericRPC_CallTo_Method')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_message_receive(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_MQE_QueueReceive')
        f.add_category('CAST_AWS_SQS_Receiver')
        f.add_category('CAST_AWS_SNS_Subscriber')
        f.add_category('CAST_Azure_ServiceBus_Receiver')
        f.add_category('CAST_Azure_Unknown_ServiceBus_Receiver')
        f.add_category('CAST_RabbitMQ_Queue')
        f.add_category('CAST_ActiveMQ_QueueReceive')
        f.add_category('CAST_RabbitMQ_Consumer')
        f.add_category('CAST_GCP_PubSub_Receiver')
        f.add_category('CAST_Azure_EventHub_Receiver')
        f.add_category('CAST_IBM_MQ_Subscriber')
        f.add_category('RPG300DataUnknownQueueReceive')
        f.add_category('CAST_MSMQ_Receiver')

        f.add_category_by_name_end('_Unknown_Receiver')
        f.add_category_by_name_end('_QueueReceive')
        f.add_category_by_name_end('_TopicReceive')
        f.add_category_by_name_end('_EventHub_Receiver')
        f.add_category_by_name_end('_Unknown_Subscriber')

        f.add_category_by_name_end('_ActiveMQ_QueueReceive')
        f.add_category_by_name_end('_IBM_QueueReceive')
        f.add_category_by_name_end('_JMS_QueueReceive')
        f.add_category_by_name_end('_Kafka_TopicReceive')
        f.add_category_by_name_end('_RabbitMQ_TopicReceive')
        f.add_category_by_name_end('_RabbitMQ_Unknown_Receiver')
        
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_message_send(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_MQE_QueueCall')
        f.add_category('CAST_AWS_SQS_Sender')
        f.add_category('CAST_AWS_SNS_Publisher')
        f.add_category('CAST_Azure_ServiceBus_Publisher')
        f.add_category('CAST_Azure_Unknown_ServiceBus_Publisher')
        f.add_category('CAST_RabbitMQ_Exchange')
        f.add_category('CAST_RabbitMQ_Publisher')
        f.add_category('CAST_GCP_PubSub_Publisher')
        f.add_category('CAST_Azure_EventHub_Publisher')
        f.add_category('CAST_IBM_MQ_Publisher')
        f.add_category('RPG300DataUnknownQueueCall')
        f.add_category('CAST_MSMQ_Sender')

        f.add_category_by_name_end('_Unknown_Publisher')
        f.add_category_by_name_end('_QueueCall')
        f.add_category_by_name_end('_TopicCall')
        f.add_category_by_name_end('_EventHub_Publisher')

        f.add_category_by_name_end('_ActiveMQ_QueueCall')
        f.add_category_by_name_end('_IBM_QueueCall')
        f.add_category_by_name_end('_JMS_QueueCall')
        f.add_category_by_name_end('_Kafka_TopicCall')

        f.add_category_by_name_end('_RabbitMQ_TopicCall')
        f.add_category_by_name_end('_RabbitMQ_Unknown_Publisher')

        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_query(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_SQL_MetricableQuery')
        f.add_category('CAST_Unknown_SQLQuery')
        f.add_category('CAST_Java_JPQLQuery')
        f.add_category('CAST_IMS_SQLQuery')
        
        f.remove_category('SPRING_BEAN')
        f.remove_category('SPRING_CONTROLLER')
        f.remove_category('SPRING_VIEW')
        
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_entity(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_Entity')
        f.add_category('CAST_Unknown_Entity')
        return f.get_result()
        
    @functools.lru_cache(maxsize=None)
    def get_entity_operation(self):

        f = Filter(self.metamodel)
        f.add_category('CAST_Entity_Operation')
        f.add_category('CAST_Unknown_Entity_Operation')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_executable(self):

        f = Filter(self.metamodel)

        f.add_category('CAST_Java_Method')
        f.add_category('CAST_Python_Method')
        f.add_category('APM Methods')
        f.add_category('templateInstanceMethod')
        f.add_category('method')
        f.add_category('APM Inventory Functions')
        f.add_category('Database Function')
        f.add_category('templateInstanceFunction')
        f.add_category('CAST_COBOL_Procedure')
        f.add_category('Database Procedure')
        f.add_category('APM Inventory Triggers')
        f.add_category('CAST_ANSISQL_Trigger')
        f.add_category('CAST_SQL_UnresolvedFunction')
        f.add_category('CAST_SQL_UnresolvedProcedure')

        f.add_category_by_name_end('_MissingTable_Procedure')
        
        return f.get_result()
        
    @functools.lru_cache(maxsize=None)
    def get_table(self):
        
        f = Filter(self.metamodel)
        f.add_category('Database Table')
        f.add_category('Database View')
        f.add_category_by_name_end('_MissingTable_Table')
        return f.get_result()
        
    @functools.lru_cache(maxsize=None)
    def get_dbms(self):
        

        f = Filter(self.metamodel)
        f.add_category('ServerObject')
        f.add_category('APM Server objects')
        f.add_category('ANSISQL')
        f.add_category('SERVER_DATABASE')
        return f.get_result()
    
        """
??? cassandra schema
https://jenkins15.corp.castsoftware.com/job/CAIP_Tool_Build_MetaModelDocumentation/HTML_20Report/category/1105006.html
https://jenkins15.corp.castsoftware.com/job/CAIP_Tool_Build_MetaModelDocumentation/HTML_20Report/category/1029005.html        
        """
    
    @functools.lru_cache(maxsize=None)
    def get_directory(self):
        
        f = Filter(self.metamodel)
        f.add_category('Directory')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_program(self):

        f = Filter(self.metamodel)
        f.add_category('APM Inventory Programs')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_class(self):
        
        f = Filter(self.metamodel)
        f.add_category('APM Classes')
        f.add_category('templateInstanceClass')
        f.add_category('CAST_ABAP_ClassOrInterface')
        f.add_category('CAST_DotNet_Type')
        f.add_category('APM Interfaces')
        f.add_category('templateInstanceInterface')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_package(self):
        
        f = Filter(self.metamodel)
        f.add_category('APM_Namespaces')
        f.add_category('APM Inventory Packages')
        f.add_category('APM Inventory Modules')
        f.add_category('APM Client Modules')
        f.add_category('SERVER_DATABASE')
        f.add_category('CAST_SQL_InstanceContainer')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_variable(self):
        
        f = Filter(self.metamodel)
        f.add_category('APM Data Members')
        f.add_category('field')
        f.add_category('CAST_DotNet_Fields')
        f.add_category('CAST_DotNet_Property')
        f.add_category('CAST_DotNet_Event')
        f.add_category('CAST_DotNet_EnumerationItem')
        f.add_category('CAST_COBOL_Data')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_index(self):
        
        f = Filter(self.metamodel)
        f.add_category('Database Index')
        f.add_category('CAST_ANSISQL_PrimaryKeyConstraint')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_foreignkey(self):
        
        f = Filter(self.metamodel)
        f.add_category('CAST_ANSISQL_ForeignKeyConstraint')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_form(self):
        
        f = Filter(self.metamodel)
        f.add_category('APM Forms')
        f.add_category('APM Controls and events')
        f.add_category('APM Inventory Events')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_default_transaction_entry(self):
        
        f = Filter(self.metamodel)
        f.add_category('APM Forms')
        f.add_category('APM IFPUG Transaction')
        f.add_category('CAST_Web_File')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_generic_remote_call(self):
        
        f = Filter(self.metamodel)
        f.add_category('CAST_Remote_Protocol_Call')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_generic_remote_receive(self):
        
        f = Filter(self.metamodel)
        f.add_category('CAST_Remote_Protocol_Receive')
        return f.get_result()

    @functools.lru_cache(maxsize=None)
    def get_input(self):
        """
        Types that represent input objects (receive)
        """
        result = set()
        
        result |= self.get_cloud_function()
        result |= self.get_program()
        result |= self.get_message_receive()
        result |= self.get_rest_web_service_receive()
        result |= self.get_rpc_receive()
        result |= self.get_soap_web_service_receive()

        return result

    @functools.lru_cache(maxsize=None)
    def get_output(self):
        """
        Types that represent output objects
        """
        result = set()
        
        result |= self.get_cloud_function_call()
        result |= self.get_message_send()
        result |= self.get_program_call()
        result |= self.get_rest_web_service_call()
        result |= self.get_rpc_call()
        result |= self.get_soap_web_service_call()
        result |= self.get_entity_operation()
        result |= self.get_query()

        return result


def find_metamodel_files(folders, allow_test_metamodel=False):
    """
    Find metamodel files in given folders
    """

    import fnmatch
    import os

    result = set()

    for folder in folders:
        for root, _, filenames in os.walk(folder):
            for filename in fnmatch.filter(filenames, '*MetaModel.xml'):
                result.add(os.path.join(root, filename))
            
            if allow_test_metamodel:
                
                for filename in fnmatch.filter(filenames, '*MetaModelTest.xml'):
                    result.add(os.path.join(root, filename))
            
            
    return result


def read_metamodel(folders, allow_partial=False, allow_test_metamodel=False):
    """
    Read a metamodel from some folders
    
    :param folders: list of pathes
    :param allow_partial: if True allow reading partial metamodels
    :param allow_test_metamodel: if True allow reading of files named xxxMetamodelTest.xml
    """
    files = find_metamodel_files(folders, allow_test_metamodel)
    result = MetaModel()

    import xml.etree.ElementTree as ET

    for file in files:
        tree = ET.parse(file)
        parse(tree.getroot(), result, file)

    result._finalize(allow_partial)

    return result


def parse(metamodel_node, metamodel, file_path=None):

    mapping = {'core': 0,
               'builtin': 1000000,
               'prepackaged': 1500000,
               'client': 2000000}
    
    if 'file_level' in metamodel_node.attrib:
        level = metamodel_node.attrib['file_level']
    else:
        level = 'core'
    if 'file_no' in metamodel_node.attrib:
        number = metamodel_node.attrib['file_no']
    else:
        number = 0
    if not number:
        number = 0

    metamodel.delta = mapping[level] + 1000 * int(number)

    for child in metamodel_node:
        if child.tag in ['type', 'partialType', 'partial_type']:
            parse_type(child, metamodel, file_path)
        elif child.tag in ['category', 'partialCategory']:
            parse_category(child, metamodel, file_path)


def is_valid(node):

    if 'status' in node.attrib:
        if node.attrib['status'] == "obsolete":
            return False

    return True


def internal_parse_attributed(node, metamodel, result):
    result.name = node.attrib['name']

    if 'id' in node.attrib:
        result.id = int(node.attrib['id'])
    if 'rid' in node.attrib:
        result.id = metamodel.delta + int(node.attrib['rid'])


def internal_parse_attribute(node, result):
    value = None
    name = node.attrib['name']
    if 'intValue' in node.attrib:
        if node.attrib['intValue']:
            value = int(node.attrib['intValue'], 0)
    else:
        value = node.attrib['stringValue']

    result.attributes[name] = value


def internal_parse_type_or_category(node, metamodel, result, file_path=None):
    internal_parse_attributed(node, metamodel, result)

    for child in node:
        if child.tag == 'description':
            result.description = child.text if child.text else '' 
        elif child.tag == 'property' and is_valid(child):
            parse_property(child, metamodel, result)
        elif child.tag == 'inheritedCategory' and is_valid(child):
            result.inherited_names.add(child.attrib['name'])
        elif child.tag == 'attribute' and is_valid(child):
            internal_parse_attribute(child, result)
    
    import xml.etree.ElementTree as ET
    
    result.xml_fragments.append((ET.tostring(node, encoding='utf-8').decode(), file_path))

def parse_type(type_node, metamodel, file_path=None):

    try:
        result = metamodel.get_category(name=type_node.attrib['name'])
    except KeyError:
        result = Type()
    internal_parse_type_or_category(type_node, metamodel, result, file_path)
    metamodel._add_type(result)


def parse_category(category_node, metamodel, file_path=None):
    try:
        result = metamodel.get_category(name=category_node.attrib['name'])
    except KeyError:
        result = Category()
    internal_parse_type_or_category(category_node, metamodel, result, file_path)
    metamodel._add_category(result)


def parse_property(node, metamodel, category):
    result = Property()
    internal_parse_attributed(node, metamodel, result)
    name = result.name
    result.name = category.name + '.' + result.name
    result.type_name = node.attrib['type']
    result.category = category

    if 'minimalCardinality' in node.attrib:
        result.minimal_cardinality = int(node.attrib['minimalCardinality'])

    if 'maximalCardinality' in node.attrib:
        cardinality = node.attrib['maximalCardinality']
        if cardinality != "*":
            result.maximal_cardinality = int(cardinality)
        else:
            result.maximal_cardinality = None

    simple_types = set(['integer',
                        'string',
                        'bookmark',
                        'reference',
                        'dateTime'])

    if result.type_name in simple_types:
        result.type = result.type_name

    list_types = set(['integerList',
                      'stringList',
                      'bookmarkList',
                      'referenceList',
                      'dateTimeList'])
    
    if result.type_name in list_types:
        result.maximal_cardinality = None

        result.type = result.type_name[:-4]

    for child in node:
        if child.tag == 'description':
            result.description = child.text if child.text else ''
        elif child.tag == 'attribute' and is_valid(child):
            internal_parse_attribute(child, result)

    category.properties.add(result)
    metamodel._add_property(result)
    result.name = name


if __name__ == "__main__":

    mm = read_metamodel(['configuration'])
    print(len(mm.get_types()))
    print(len(mm.get_categories()))
    print(mm.get_category(name="CAST_COBOL_Select"))
